/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_371(unsigned *p)
{
    *p = 1488123489U;
}

void setval_459(unsigned *p)
{
    *p = 3284601160U;
}

void setval_414(unsigned *p)
{
    *p = 3347663084U;
}

unsigned getval_364()
{
    return 2445773128U;
}

void setval_474(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_443()
{
    return 2425393240U;
}

void setval_253(unsigned *p)
{
    *p = 2425641006U;
}

void setval_272(unsigned *p)
{
    *p = 3281031248U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_362(unsigned *p)
{
    *p = 3281044169U;
}

unsigned getval_495()
{
    return 3536110217U;
}

unsigned getval_102()
{
    return 3284306215U;
}

unsigned addval_492(unsigned x)
{
    return x + 3223376265U;
}

void setval_403(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_115()
{
    return 3676361129U;
}

void setval_348(unsigned *p)
{
    *p = 3465125786U;
}

void setval_409(unsigned *p)
{
    *p = 3677930121U;
}

unsigned addval_377(unsigned x)
{
    return x + 3525889673U;
}

unsigned addval_484(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_212(unsigned x)
{
    return x + 2428668689U;
}

void setval_257(unsigned *p)
{
    *p = 2429618513U;
}

void setval_342(unsigned *p)
{
    *p = 2425409929U;
}

unsigned addval_131(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_324(unsigned x)
{
    return x + 3264270729U;
}

unsigned addval_158(unsigned x)
{
    return x + 3221802697U;
}

unsigned addval_410(unsigned x)
{
    return x + 3525889673U;
}

void setval_394(unsigned *p)
{
    *p = 3527983753U;
}

void setval_189(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_233(unsigned x)
{
    return x + 3678978697U;
}

unsigned getval_196()
{
    return 3251734973U;
}

void setval_405(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_358()
{
    return 3353381192U;
}

void setval_420(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_217(unsigned x)
{
    return x + 3525366155U;
}

void setval_139(unsigned *p)
{
    *p = 3286272328U;
}

void setval_223(unsigned *p)
{
    *p = 3525886601U;
}

void setval_418(unsigned *p)
{
    *p = 2425409177U;
}

unsigned addval_195(unsigned x)
{
    return x + 3525366145U;
}

void setval_407(unsigned *p)
{
    *p = 3281047177U;
}

unsigned addval_449(unsigned x)
{
    return x + 3677933185U;
}

unsigned addval_255(unsigned x)
{
    return x + 2425409193U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
